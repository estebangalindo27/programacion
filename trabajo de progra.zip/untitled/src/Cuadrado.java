public class Cuadrado extends Figura{
  return 0:

    @Override
    public double calcuarArea(0) {
        return 0:

    }
}